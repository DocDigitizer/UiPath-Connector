﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Models
{
    [Serializable]
    public class GetRejectionResponse
    {
        [JsonProperty("detail")]
        public string Detail { get; set; }

        [JsonProperty("rejection")]
        public Rejection Rejection { get; set; }

        [JsonProperty("status")]
        public int Status { get; set; }

        [JsonIgnore]
        public HttpStatusCode HttpStatusCode { get; set; }

        [JsonIgnore]
        public string Payload { get; set; }
    }
}
