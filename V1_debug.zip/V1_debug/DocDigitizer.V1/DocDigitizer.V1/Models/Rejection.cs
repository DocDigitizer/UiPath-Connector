﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Models
{
    [Serializable]
    public class Rejection
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("justification")]
        public string Justification { get; set; }

        [JsonProperty("justification_code")]
        public string JustificationCode { get; set; }

        [JsonProperty("rejected_at")]
        public DateTime RejectedAt { get; set; }
    }
}
