﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Models
{
    [Serializable]
    public class SubmitDocumentResponse
    {
        public HttpStatusCode HttpStatusCode { get; set; }

        public TaskResponse? TaskResponse { get; set; }

        public CustomStatus CustomStatus { get; set; }

        public string DocumentId { get; set; }

        public string TaskId { get; set; }

        public string Payload { get; set; }

    }
}
