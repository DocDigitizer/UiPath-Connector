﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Models
{
    [Serializable]
    public class Links
    {
        [JsonProperty("self")]

        public string Self { get; set; }

        [JsonProperty("collection")]
        public string Collection { get; set; }

        [JsonProperty("reviews")]
        public string Reviews { get; set; }

        [JsonProperty("annotations")]
        public string Annotations { get; set; }

        [JsonProperty("assets")]
        public string Assets { get; set; }

        [JsonProperty("document")]
        public string Document { get; set; }
    }
}
