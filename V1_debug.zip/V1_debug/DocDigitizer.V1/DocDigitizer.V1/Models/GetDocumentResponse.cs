﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Models
{

    [Serializable]
    public class GetDocumentResponse
    {
        public HttpStatusCode HttpStatusCode { get; set; }

        public string Payload { get; set; }

    }
}
