﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Models
{
    [Serializable]
    public class TaskResponse
    {
        [JsonProperty("status")]
        public int Status { get; set; }

        [JsonProperty("detail")]
        public string Detail { get; set; }

        [JsonProperty("task")]
        public CustomTask Task { get; set; }

        //[JsonIgnore]
        //public string DocumentId { get; set; }
    }
}
