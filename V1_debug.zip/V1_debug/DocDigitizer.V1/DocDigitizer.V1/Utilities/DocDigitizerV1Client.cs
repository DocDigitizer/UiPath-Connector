﻿using DocDigitizer.V1.Exceptions;
using DocDigitizer.V1.Models;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DocDigitizer.V1.Utilities
{
    public class DocDigitizerV1Client
    {

        public const string DEFAULT_APIKEY = "";
        public const string BASEURL = "https://api.docdigitizer.com/";
        private const int DEFAULT_TIMEOUT_SECONDS = 5;

        public string BaseUrl { get; set; }

        public string ApiKey { get; set; }

        public int TimeoutSeconds { get; set; }


        public DocDigitizerV1Client(string baseUrl = BASEURL, string apiKey = DEFAULT_APIKEY, int timeOutSecs = DEFAULT_TIMEOUT_SECONDS)
        {
            BaseUrl = baseUrl;
            TimeoutSeconds = timeOutSecs;
            ApiKey = apiKey;
        }




        




        public SubmitDocumentResponse SubmitDocument(string filepath, string document_class = null, string callback_url = null, string callback_method = null, Dictionary<string,string> callback_headers = null)
        {

            
            var response = new SubmitDocumentResponse()
            {
                HttpStatusCode = HttpStatusCode.Accepted,
                Payload = "Info stuff",
                DocumentId = Guid.Empty.ToString()
            };

                        
            return response;
        }

        public GetDocumentResponse GetDocument(string documentid)
        {
            
            if (string.IsNullOrWhiteSpace(documentid))
            {
                throw new MissingFieldException("Document id is missing");
            }
            
            var response = new GetDocumentResponse()
            {
                HttpStatusCode = HttpStatusCode.OK,
                Payload = "Document Data"
            };

            return response;
        }
                
        public GetRejectionResponse GetRejection(string documentid)
        {

            if (string.IsNullOrWhiteSpace(documentid))
            {
                throw new MissingFieldException("Document id is missing");
            }

            var response = new GetRejectionResponse()
            {
                HttpStatusCode = HttpStatusCode.OK,
                Payload = "Document Rejection"
            };

            return response;
        }


        

    }
}
