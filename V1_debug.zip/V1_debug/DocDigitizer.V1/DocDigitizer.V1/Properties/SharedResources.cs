﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : DocDigitizer.V1.Properties.Resources
    {
    }
}