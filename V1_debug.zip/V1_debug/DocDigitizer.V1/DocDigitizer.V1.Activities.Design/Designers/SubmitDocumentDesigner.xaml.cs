namespace DocDigitizer.V1.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SubmitDocumentDesigner.xaml
    /// </summary>
    public partial class SubmitDocumentDesigner
    {
        public SubmitDocumentDesigner()
        {
            InitializeComponent();
        }
    }
}
