﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : DocDigitizer.V1.Activities.Design.Properties.Resources
    {
    }
}