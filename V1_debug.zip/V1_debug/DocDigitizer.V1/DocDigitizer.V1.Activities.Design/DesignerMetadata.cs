using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using DocDigitizer.V1.Activities.Design.Designers;
using DocDigitizer.V1.Activities.Design.Properties;

namespace DocDigitizer.V1.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(SubmitDocument), categoryAttribute);
            builder.AddCustomAttributes(typeof(SubmitDocument), new DesignerAttribute(typeof(SubmitDocumentDesigner)));
            builder.AddCustomAttributes(typeof(SubmitDocument), new HelpKeywordAttribute(""));

            //builder.AddCustomAttributes(typeof(GetDocumentInformation), categoryAttribute);
            //builder.AddCustomAttributes(typeof(GetDocumentInformation), new DesignerAttribute(typeof(GetDocumentInformationDesigner)));
            //builder.AddCustomAttributes(typeof(GetDocumentInformation), new HelpKeywordAttribute(""));

            //builder.AddCustomAttributes(typeof(GetDocumentRejection), categoryAttribute);
            //builder.AddCustomAttributes(typeof(GetDocumentRejection), new DesignerAttribute(typeof(GetDocumentRejectionDesigner)));
            //builder.AddCustomAttributes(typeof(GetDocumentRejection), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
