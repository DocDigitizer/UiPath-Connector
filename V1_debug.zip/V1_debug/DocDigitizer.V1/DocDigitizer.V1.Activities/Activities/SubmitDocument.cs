using System;
using System.Activities;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DocDigitizer.V1.Activities.Properties;
using DocDigitizer.V1.Models;
using DocDigitizer.V1.Utilities;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace DocDigitizer.V1.Activities
{
    [LocalizedDisplayName(nameof(Resources.SubmitDocument_DisplayName))]
    [LocalizedDescription(nameof(Resources.SubmitDocument_Description))]
    public class SubmitDocument : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.API_BASEURL_DisplayName))]
        [LocalizedDescription(nameof(Resources.API_BASEURL_Description))]
        [LocalizedCategory(nameof(Resources.Authentication_Category))]
        public InArgument<string> API_BASEURL { get; set; } = DocDigitizerV1Client.BASEURL;

        [LocalizedDisplayName(nameof(Resources.API_KEY_DisplayName))]
        [LocalizedDescription(nameof(Resources.API_KEY_Description))]
        [LocalizedCategory(nameof(Resources.Authentication_Category))]
        public InArgument<string> API_KEY { get; set; } = DocDigitizerV1Client.DEFAULT_APIKEY;

        [LocalizedDisplayName(nameof(Resources.SubmitDocument_DocumentPath_DisplayName))]
        [LocalizedDescription(nameof(Resources.SubmitDocument_DocumentPath_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> DocumentPath { get; set; }

        [LocalizedDisplayName(nameof(Resources.SubmitDocument_DocumentClass_DisplayName))]
        [LocalizedDescription(nameof(Resources.SubmitDocument_DocumentClass_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> DocumentClass { get; set; }

        [LocalizedDisplayName(nameof(Resources.SubmitDocument_CallbackURL_DisplayName))]
        [LocalizedDescription(nameof(Resources.SubmitDocument_CallbackURL_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> CallbackURL { get; set; }

        [LocalizedDisplayName(nameof(Resources.SubmitDocument_CallbackMethod_DisplayName))]
        [LocalizedDescription(nameof(Resources.SubmitDocument_CallbackMethod_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> CallbackMethod { get; set; }

        [LocalizedDisplayName(nameof(Resources.SubmitDocument_CallbackHeaders_DisplayName))]
        [LocalizedDescription(nameof(Resources.SubmitDocument_CallbackHeaders_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<Dictionary<string,string>> CallbackHeaders { get; set; }

        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.Timeout_DisplayName))]
        [LocalizedDescription(nameof(Resources.Timeout_Description))]
        public InArgument<int> TimeoutMS { get; set; } = 60000;


        [LocalizedDisplayName(nameof(Resources.SubmitDocument_SubmitDocumentResponse_DisplayName))]
        [LocalizedDescription(nameof(Resources.SubmitDocument_SubmitDocumentResponse_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<Models.SubmitDocumentResponse> SubmitDocumentResponse { get; set; }

        #endregion


        #region Constructors

        public SubmitDocument()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (API_BASEURL == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(API_BASEURL)));
            if (API_KEY == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(API_KEY)));
            if (DocumentPath == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(DocumentPath)));
            //if (SubmitDocumentResponse == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(SubmitDocumentResponse)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var timeoutSecs = TimeoutMS.Get(context) / 1000;
            var apiUrl = API_BASEURL.Get(context);
            var apiKEY = API_KEY.Get(context);
            var documentPath = DocumentPath.Get(context);
            var documentClass = DocumentClass.Get(context);
            var callbackUrl = CallbackURL.Get(context);
            var callbackMethod = CallbackMethod.Get(context);
            var callbackHeaders = CallbackHeaders.Get(context);

            var client = new Utilities.DocDigitizerV1Client(apiUrl, apiKEY, timeoutSecs);
            var resp = client.SubmitDocument(documentPath, documentClass, callbackUrl, callbackMethod, callbackHeaders);

            return (ctx) =>
            {
                SubmitDocumentResponse.Set(ctx, resp);
            };
        }

        //protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        //{
        //    // Inputs
        //    var timeout = TimeoutMS.Get(context);

        //    // Set a timeout on the execution
        //    var task = ExecuteWithTimeout(context, cancellationToken);
        //    if (await Task.WhenAny(task, Task.Delay(timeout, cancellationToken)) != task) throw new TimeoutException(Resources.Timeout_Error);

        //    // Outputs
        //    //return (ctx) => {
        //    //};
        //    return task.Result;
        //}

        //private async Task<Action<AsyncCodeActivityContext>> ExecuteWithTimeout(AsyncCodeActivityContext context, CancellationToken cancellationToken = default)
        //{
        //    // Inputs
        //    var timeoutSecs = TimeoutMS.Get(context)/1000;
        //    var apiUrl = API_BASEURL.Get(context);
        //    var apiKEY = API_KEY.Get(context);
        //    var documentPath = DocumentPath.Get(context);
        //    var documentClass = DocumentClass.Get(context);
        //    var callbackUrl = CallbackURL.Get(context);
        //    var callbackMethod = CallbackMethod.Get(context);
        //    var callbackHeaders = CallbackHeaders.Get(context);

        //    var client = new Utilities.DocDigitizerV1Client(apiUrl, apiKEY, timeoutSecs);
        //    var resp = client.SubmitDocument(documentPath, documentClass, callbackUrl, callbackMethod, callbackHeaders);

        //    return (ctx) => {
        //        SubmitDocumentResponse.Set(ctx, resp);
        //    };
        //}

        #endregion
    }
}

